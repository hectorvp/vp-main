cli-main-stub
=============



[![oclif](https://img.shields.io/badge/cli-oclif-brightgreen.svg)](https://oclif.io)
[![Version](https://img.shields.io/npm/v/cli-main-stub.svg)](https://npmjs.org/package/cli-main-stub)
[![Downloads/week](https://img.shields.io/npm/dw/cli-main-stub.svg)](https://npmjs.org/package/cli-main-stub)
[![License](https://img.shields.io/npm/l/cli-main-stub.svg)](https://github.com/hpeters83/cli-main-stub/blob/master/package.json)

<!-- toc -->
* [Usage](#usage)
* [Commands](#commands)
<!-- tocstop -->
# Usage
<!-- usage -->
```sh-session
$ npm install -g @tibco-cloud/cli-main
$ tcloud COMMAND
running command...
$ tcloud (-v|--version|version)
@tibco-cloud/cli-main/0.0.0 darwin-x64 node-v14.17.1
$ tcloud --help [COMMAND]
USAGE
  $ tcloud COMMAND
...
```
<!-- usagestop -->
# Commands
<!-- commands -->
* [`tcloud asyncapi:transform`](#tcloud-asyncapitransform)
* [`tcloud config:add-profile`](#tcloud-configadd-profile)
* [`tcloud config:initialize`](#tcloud-configinitialize)
* [`tcloud config:list-profiles`](#tcloud-configlist-profiles)
* [`tcloud config:remove-profile`](#tcloud-configremove-profile)
* [`tcloud help [COMMAND]`](#tcloud-help-command)
* [`tcloud plugins`](#tcloud-plugins)
* [`tcloud plugins:inspect PLUGIN...`](#tcloud-pluginsinspect-plugin)
* [`tcloud plugins:install PLUGIN...`](#tcloud-pluginsinstall-plugin)
* [`tcloud plugins:link PLUGIN`](#tcloud-pluginslink-plugin)
* [`tcloud plugins:uninstall PLUGIN...`](#tcloud-pluginsuninstall-plugin)
* [`tcloud plugins:update`](#tcloud-pluginsupdate)

## `tcloud asyncapi:transform`

Transform AsyncAPI spec to Flogo Or Flogo to AsyncAPI spec

```
USAGE
  $ tcloud asyncapi:transform

OPTIONS
  -f, --from=from          (required) Path to the source file
  -s, --server=server      Server name in asyncapi spec. Comma separated servers incase of Kafka Cluster
  -t, --to=flogo|asyncapi  [default: flogo] conversion type
  --no-warnings            Disable warnings from commands outputs
  --profile=profile        Switch to different org or region using profile

EXAMPLE
  tcloud asyncapi:transform --to flogo --from ./asyncapispec.json
```

_See code: [asyncapi](https://github.com/hectorvp/asyncapi-flogo/blob/v0.1.0/src/commands/asyncapi/transform.ts)_

## `tcloud config:add-profile`

Add profiles to the configuration

```
USAGE
  $ tcloud config:add-profile

OPTIONS
  -n, --name=name        Name of the default profile
  -r, --region=us|eu|au  Region
  --no-warnings          Disable warnings from commands outputs
  --profile=profile      Switch to different org or region using profile
```

_See code: [src/commands/config/add-profile.ts](https://github.com/hpeters83/cli-main-stub/blob/v0.0.0/src/commands/config/add-profile.ts)_

## `tcloud config:initialize`

Initialize CLI

```
USAGE
  $ tcloud config:initialize

OPTIONS
  --no-warnings      Disable warnings from commands outputs
  --profile=profile  Switch to different org or region using profile
```

_See code: [src/commands/config/initialize.ts](https://github.com/hpeters83/cli-main-stub/blob/v0.0.0/src/commands/config/initialize.ts)_

## `tcloud config:list-profiles`

List all configured profiles

```
USAGE
  $ tcloud config:list-profiles

OPTIONS
  --no-warnings      Disable warnings from commands outputs
  --profile=profile  Switch to different org or region using profile
```

_See code: [src/commands/config/list-profiles.ts](https://github.com/hpeters83/cli-main-stub/blob/v0.0.0/src/commands/config/list-profiles.ts)_

## `tcloud config:remove-profile`

Remove profiles from configuration

```
USAGE
  $ tcloud config:remove-profile

OPTIONS
  -n, --name=name    Name of the profile to be removed
  --no-warnings      Disable warnings from commands outputs
  --profile=profile  Switch to different org or region using profile
```

_See code: [src/commands/config/remove-profile.ts](https://github.com/hpeters83/cli-main-stub/blob/v0.0.0/src/commands/config/remove-profile.ts)_

## `tcloud help [COMMAND]`

display help for tcloud

```
USAGE
  $ tcloud help [COMMAND]

ARGUMENTS
  COMMAND  command to show help for

OPTIONS
  --all  see all commands in CLI
```

_See code: [@oclif/plugin-help](https://github.com/oclif/plugin-help/blob/v3.2.2/src/commands/help.ts)_

## `tcloud plugins`

list installed plugins

```
USAGE
  $ tcloud plugins

OPTIONS
  --core  show core plugins

EXAMPLE
  $ tcloud plugins
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/index.ts)_

## `tcloud plugins:inspect PLUGIN...`

displays installation properties of a plugin

```
USAGE
  $ tcloud plugins:inspect PLUGIN...

ARGUMENTS
  PLUGIN  [default: .] plugin to inspect

OPTIONS
  -h, --help     show CLI help
  -v, --verbose

EXAMPLE
  $ tcloud plugins:inspect myplugin
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/inspect.ts)_

## `tcloud plugins:install PLUGIN...`

installs a plugin into the CLI

```
USAGE
  $ tcloud plugins:install PLUGIN...

ARGUMENTS
  PLUGIN  plugin to install

OPTIONS
  -f, --force    yarn install with force flag
  -h, --help     show CLI help
  -v, --verbose

DESCRIPTION
  Can be installed from npm or a git url.

  Installation of a user-installed plugin will override a core plugin.

  e.g. If you have a core plugin that has a 'hello' command, installing a user-installed plugin with a 'hello' command 
  will override the core plugin implementation. This is useful if a user needs to update core plugin functionality in 
  the CLI without the need to patch and update the whole CLI.

ALIASES
  $ tcloud plugins:add

EXAMPLES
  $ tcloud plugins:install myplugin 
  $ tcloud plugins:install https://github.com/someuser/someplugin
  $ tcloud plugins:install someuser/someplugin
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/install.ts)_

## `tcloud plugins:link PLUGIN`

links a plugin into the CLI for development

```
USAGE
  $ tcloud plugins:link PLUGIN

ARGUMENTS
  PATH  [default: .] path to plugin

OPTIONS
  -h, --help     show CLI help
  -v, --verbose

DESCRIPTION
  Installation of a linked plugin will override a user-installed or core plugin.

  e.g. If you have a user-installed or core plugin that has a 'hello' command, installing a linked plugin with a 'hello' 
  command will override the user-installed or core plugin implementation. This is useful for development work.

EXAMPLE
  $ tcloud plugins:link myplugin
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/link.ts)_

## `tcloud plugins:uninstall PLUGIN...`

removes a plugin from the CLI

```
USAGE
  $ tcloud plugins:uninstall PLUGIN...

ARGUMENTS
  PLUGIN  plugin to uninstall

OPTIONS
  -h, --help     show CLI help
  -v, --verbose

ALIASES
  $ tcloud plugins:unlink
  $ tcloud plugins:remove
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/uninstall.ts)_

## `tcloud plugins:update`

update installed plugins

```
USAGE
  $ tcloud plugins:update

OPTIONS
  -h, --help     show CLI help
  -v, --verbose
```

_See code: [@oclif/plugin-plugins](https://github.com/oclif/plugin-plugins/blob/v1.10.1/src/commands/plugins/update.ts)_
<!-- commandsstop -->
