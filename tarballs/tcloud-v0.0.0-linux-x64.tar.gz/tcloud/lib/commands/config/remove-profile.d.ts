import { flags } from '@oclif/command';
import { BaseCommand } from '@tibco-cloud/cli-core';
export default class ConfigRemoveProfile extends BaseCommand {
    static description: string;
    static flags: {
        name: flags.IOptionFlag<string | undefined>;
        profile: flags.IOptionFlag<string | undefined>;
        'no-warnings': import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    run(): Promise<void>;
}
