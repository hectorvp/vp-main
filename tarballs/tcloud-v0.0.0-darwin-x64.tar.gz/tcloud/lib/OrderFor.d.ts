import { flags } from '@oclif/command';
import { BaseCommand } from '@tibco-cloud/cli-core';
export default class OrderFor extends BaseCommand {
    static description: string;
    static examples: string[];
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        meal: flags.IOptionFlag<string | undefined>;
        profile: flags.IOptionFlag<string | undefined>;
        'no-warnings': import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: {
        name: string;
    }[];
    run(): Promise<void>;
}
