/// <reference types="node" />
import { region } from '@tibco-cloud/cli-core';
import { EventEmitter } from 'events';
import { GenerateTokenResponse, RegisterClientResponse } from '../models';
export declare function startLocalServer(event: EventEmitter): Promise<string>;
export declare function requestListener(event: EventEmitter): (req: any, res: any) => any;
export declare function registerClient(redirect_uri: string): Promise<RegisterClientResponse>;
export declare function getBrowserURL(scope: string[], region: region, serverAddrs: string, clientId: string): string;
export declare function generateToken(clientId: string, clientSecret: string, serverAddrs: string, code: string, region: region): Promise<GenerateTokenResponse>;
export declare function stopLocalServer(): Promise<void>;
