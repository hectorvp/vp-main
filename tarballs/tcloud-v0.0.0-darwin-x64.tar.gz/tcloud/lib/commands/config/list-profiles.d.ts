import { BaseCommand } from '@tibco-cloud/cli-core';
export default class ConfigListProfiles extends BaseCommand {
    static description: string;
    run(): Promise<void>;
}
