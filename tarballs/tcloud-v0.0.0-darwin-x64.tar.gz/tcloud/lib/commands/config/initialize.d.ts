import { region, BaseCommand } from '@tibco-cloud/cli-core';
import { GenerateTokenResponse, RegisterClientResponse } from '../../models';
export default class ConfigInitialize extends BaseCommand {
    static description: string;
    run(): Promise<void>;
    storeConfigData(clientInfo: RegisterClientResponse, tokenInfo: GenerateTokenResponse, region: region, org: string): void;
    finally(): Promise<void>;
}
