import { BaseCommand } from "@tibco-cloud/cli-core";
export default class Cicmenu extends BaseCommand {
    static description: string;
    static flags: {
        profile: import("@oclif/command/lib/flags").IOptionFlag<string | undefined>;
        'no-warnings': import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: {
        name: string;
    }[];
    run(): Promise<void>;
    private printHeader;
}
